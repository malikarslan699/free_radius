

#!/bin/bash
apt-get update
 
clear
radius=$(/etc/init.d/freeradius status | grep running | grep -v not | wc -l);
if [ "$radius" -ne 1 ];
then
sudo add-apt-repository ppa:freeradius/stable-2.x
apt-get -y install freeradius freeradius-mysql
cp default /etc/freeradius/3.0/sites-enabled/default

fi

 

apt-get -y install ocserv
cd
mkdir /temp
cp ocserv/temp/* /temp/
chmod -R 777 /temp/
cp ocserv/ocserv.conf  /etc/ocserv/
cp servers /etc/radcli/
sed -i "s/#net.ipv4.ip_forward=1/net.ipv4.ip_forward = 1/g" /etc/sysctl.conf

sudo sysctl -p
 apt-get -y install ufw
sudo ufw allow 22/tcp
cp ufw /etc/default/ufw
cp before.rules /etc/ufw/before.rules


ufw allow ssh

sudo ufw allow 443/tcp
sudo ufw allow 443/udp
iptables -t nat -L POSTROUTING
sudo ufw default allow FORWARD


ufw allow "Apache Full"
DEFAULT_FORWARD_POLICY="ACCEPT"
sed -i "s/#net.ipv4.ip_forward=1/net.ipv4.ip_forward = 1/g" /etc/sysctl.conf
sed -i "s/#localhost/localhost/g" /etc/radcli/servers
sudo ufw enable
sudo sysctl -p

sudo /etc/init.d/ocserv restart
sudo /etc/init.d/freeradius restart


















