#!/bin/bash

USERNAME=$1
PASS=$2
if [ "$PASS" = "Stop" ] ; then
data=$(curl -sb -x POST  -F "username=$USERNAME" -F "password=$PASS" "disconnect apilink ")
fi

