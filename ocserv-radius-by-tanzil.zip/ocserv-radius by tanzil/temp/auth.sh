#!/bin/bash
USERNAME=$1
PASS=$2

data=$(curl -sb -x POST  -F "username=$USERNAME" -F "password=$PASS" "https://onionvpn.net/connection")
if [ "$data" -eq "1" ]; then 
	echo "$USERNAME | $PASS is invalid"
	echo REJECT 
else
	echo ACCEPT
fi


